#include <iostream>
using namespace std;

bool sorted(int *a, int n) {
    if (n <= 1)
        return true;

    if (a[0] >= a[1] && sorted(a + 1, n - 1))
        return true;

    return false;
}

int main() {
    const int MAX_SIZE = 100;
    int n = 0;
    int a[MAX_SIZE];

    while (n < MAX_SIZE) {
        int num;
        cin >> num;
        if (num == -1)
            break;
        a[n++] = num;
    }

    if (n <= 1) {
        cout << "Sorted"; 
        return 0;
    }

    if (sorted(a, n))
        cout << "Sorted";
    else
        cout << "Not Sorted";

    return 0;
}
