#include <iostream>
using namespace std;

bool sorted(int *a, int n) {
    if (n <= 1)
        return true;

    if (a[0] >= a[1] && sorted(a + 1, n - 1))
        return true;

    return false;
}

int main() {
    const int MAX_SIZE = 100;
    int n = 0;
    int a[MAX_SIZE];

    cin >> n;

    if (n <= 0 || n > MAX_SIZE) {
        cout << endl;
        return 1;
    }

    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }

    if (n == 0 || sorted(a, n))
        cout << "Sorted";
    else
        cout << "Not Sorted";

    return 0;
}
