#include <iostream> 
#include <sstream>
#include <string>


int main() {
    std::string input;
    std::getline(std::cin, input);

    std::string
}